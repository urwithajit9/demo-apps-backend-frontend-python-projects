export const MAX_USERNAME_LENGTH = 40;
