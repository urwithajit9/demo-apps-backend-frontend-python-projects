export const PRIVATE_ROUTES = ['preview', 'api', 'upload', 'pdf'];
