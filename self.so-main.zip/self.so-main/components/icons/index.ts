import { GitHubIcon } from './GitHubIcon';
import { LinkedInIcon } from './LinkedInIcon';
import { XIcon } from './XIcon';

export { GitHubIcon, LinkedInIcon, XIcon };
