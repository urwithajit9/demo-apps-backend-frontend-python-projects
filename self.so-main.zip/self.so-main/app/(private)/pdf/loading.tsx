import LoadingFallback from '@/components/LoadingFallback';

export default function LoadingPreview() {
  return <LoadingFallback message="" />;
}
