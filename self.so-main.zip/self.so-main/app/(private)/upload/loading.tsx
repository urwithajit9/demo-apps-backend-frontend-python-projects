import LoadingFallback from '@/components/LoadingFallback';

export default function LoadingUpload() {
  return <LoadingFallback message="" />;
}
