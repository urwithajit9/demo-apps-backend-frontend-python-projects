import UploadPageClient from './client';

export default async function UploadPage() {
  return <UploadPageClient />;
}
