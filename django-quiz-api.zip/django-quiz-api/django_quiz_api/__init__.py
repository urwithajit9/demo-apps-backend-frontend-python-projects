# Package initialization
default_app_config = 'django_quiz_api.apps.DjangoQuizApiConfig'
