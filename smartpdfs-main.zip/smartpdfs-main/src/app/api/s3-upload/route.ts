export { POST } from "next-s3-upload/route";
