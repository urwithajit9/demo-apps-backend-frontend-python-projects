# Research Papers by Dr. Ajit Kumar (Pondicherry University)

## Malware Analysis and Detection Research

1. **A Framework for Malware Detection with Static Features using Machine Learning Algorithms**
   - **Author(s):** Ajit Kumar
   - **Type:** PhD Thesis
   - **Institution:** Pondicherry University (May 2018)
   - **Description:** Dr. Kumar's PhD thesis focused on malware detection using machine learning with static features.

2. **PACER: Platform for Android Malware Classification, Performance Evaluation and Threat Reporting**
   - **Author(s):** Ajit Kumar, Vinti Agarwal, Shishir Kumar Shandilya, Andrii Shalaginov, Saket Upadhyay, Bhawna Yadav
   - **Publication:** Future Internet 2020, 12(4), 66
   - **Type:** Extended Version
   - **Focus:** Android malware classification platform with performance evaluation metrics

3. **PACE: Platform for Android Malware Classification and Performance Evaluation**
   - **Author(s):** Ajit Kumar, Vinti Agarwal, Shishir Kumar Shandilya, Andrii Shalaginov, Saket Upadhyay, Bhawna Yadav
   - **Publication:** IEEE International Conference on Big Data (Big Data), Los Angeles, CA, USA, 2019
   - **Award:** Best Paper
   - **Focus:** Platform for classifying Android malware with performance evaluation metrics

4. **Features for Detecting Malware on Computing Environments**
   - **Author(s):** Ajit Kumar, K S Kuppusamy, G. Aghila
   - **Publication:** Future Generation Computer Systems 2018
   - **Description:** Summarizes different features used with machine learning to detect malware in various computing environments

5. **A learning model to detect maliciousness of portable executable using integrated feature set**
   - **Author(s):** Ajit Kumar, K S Kuppusamy, G. Aghila
   - **Publication:** Journal of King Saud University-Computer and Information Sciences
   - **Focus:** Detection of malicious portable executable files using integrated feature sets

6. **Machine learning based malware classification for Android applications using multimodal image representations**
   - **Author(s):** Ajit Kumar, K Pramod Sagar, KS Kuppusamy, G Aghila
   - **Publication:** Intelligent Systems and Control (ISCO), 2016 10th International Conference
   - **Focus:** Using multimodal image representations for Android malware classification

7. **Portable executable scoring: What is your malicious score?**
   - **Author(s):** Ajit Kumar, G. Aghila
   - **Publication:** 2014 International Conference on Science Engineering and Management Research (ICSEMR)
   - **Description:** Proposes a static heuristic-based scoring system for portable executable files to determine maliciousness

8. **FAMOUS: Forensic Analysis of MObile devices Using Scoring of application permissions**
   - **Author(s):** Ajit Kumar, K S Kuppusamy, G. Aghila
   - **Publication:** Future Generation Computer Systems 2018
   - **Focus:** Forensic analysis of mobile devices using application permission scoring

## Related Research

1. **AI-assisted Computer Network Operations testbed for Nature-Inspired Cyber Security based adaptive defense simulation and analysis**
   - **Author(s):** Shishir Kumar Shandilya, Saket Upadhyay, Ajit Kumar, Atulya K. Nagar
   - **Publication:** Future Generation Computer Systems
   - **Relevance:** AI-based adaptive defense simulation for cybersecurity

2. **Machine Learning Algorithm for Detection of False Data Injection Attack in Power System**
   - **Author(s):** Ajit Kumar, Neetesh Saxena, Bong Jun Choi
   - **Publication:** 35th International Conference on Information Networking (ICOIN 2021)
   - **Award:** Best Paper
   - **Relevance:** Machine learning for attack detection in critical infrastructure

## Research Focus Areas

Dr. Ajit Kumar's research primarily focuses on:

1. **Malware Detection and Classification:**
   - Static analysis of malware
   - Machine learning approaches for malware detection
   - Feature extraction and selection for malware analysis

2. **Mobile Security:**
   - Android malware classification
   - Permission-based analysis of mobile applications
   - Forensic analysis of mobile devices

3. **Portable Executable Analysis:**
   - Scoring systems for maliciousness detection
   - Static heuristic-based analysis
   - Integrated feature sets for PE file analysis

4. **Machine Learning Applications in Security:**
   - Multimodal image representations for malware
   - Feature engineering for security applications
   - Performance evaluation of ML-based security systems

## Contact Information
- **Email:** ajitkumar.pu@gmail.com
- **Current Position:** Post Doctoral researcher at Soongsil University, Seoul, South Korea
- **Previous Affiliation:** Department of Computer Science, Pondicherry University
