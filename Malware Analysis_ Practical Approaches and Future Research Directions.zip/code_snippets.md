# Malware Analysis Code Snippets and Examples

This document provides practical code examples for key malware analysis concepts, serving as a refresher for students with security backgrounds.

## 1. Basic Static Analysis with Python

### Example 1: Extracting PE File Information

```python
import pefile
import sys

def analyze_pe(file_path):
    """Basic static analysis of PE files"""
    try:
        # Load the PE file
        pe = pefile.PE(file_path)
        
        # Print basic file information
        print(f"[*] File: {file_path}")
        print(f"[*] Image Base: 0x{pe.OPTIONAL_HEADER.ImageBase:08x}")
        print(f"[*] Entry Point: 0x{pe.OPTIONAL_HEADER.AddressOfEntryPoint:08x}")
        print(f"[*] Number of Sections: {pe.FILE_HEADER.NumberOfSections}")
        
        # Print sections information
        print("\n[*] Sections:")
        for section in pe.sections:
            print(f"    {section.Name.decode().rstrip('\\x00')}:")
            print(f"      Virtual Address: 0x{section.VirtualAddress:08x}")
            print(f"      Size: {section.SizeOfRawData} bytes")
            print(f"      Entropy: {section.get_entropy():.2f}")
        
        # Print imported functions
        print("\n[*] Imported Functions:")
        for entry in pe.DIRECTORY_ENTRY_IMPORT:
            print(f"    {entry.dll.decode()}")
            for imp in entry.imports:
                if imp.name:
                    print(f"      {imp.name.decode()}")
                else:
                    print(f"      Ordinal: {imp.ordinal}")
        
        # Check for suspicious characteristics
        suspicious = []
        if pe.OPTIONAL_HEADER.DATA_DIRECTORY[pefile.DIRECTORY_ENTRY['IMAGE_DIRECTORY_ENTRY_SECURITY']].VirtualAddress == 0:
            suspicious.append("Unsigned binary")
        
        if hasattr(pe, 'DIRECTORY_ENTRY_TLS'):
            suspicious.append("Contains TLS callbacks (potential anti-debugging)")
        
        if pe.FILE_HEADER.Characteristics & 0x2000:
            suspicious.append("DLL can be relocated at load time")
        
        if suspicious:
            print("\n[!] Suspicious characteristics:")
            for s in suspicious:
                print(f"    - {s}")
        
    except Exception as e:
        print(f"[!] Error: {e}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <pe_file>")
        sys.exit(1)
    
    analyze_pe(sys.argv[1])
```

### Example 2: String Extraction and Analysis

```python
import re
import sys
import os
import binascii

def extract_strings(file_path, min_length=4):
    """Extract ASCII and Unicode strings from a binary file"""
    with open(file_path, 'rb') as f:
        data = f.read()
    
    # ASCII strings
    ascii_pattern = re.compile(b'[\x20-\x7E]{' + str(min_length).encode() + b',}')
    ascii_strings = ascii_pattern.findall(data)
    
    # Unicode strings (UTF-16LE, common in Windows)
    unicode_pattern = re.compile(b'(?:[\x20-\x7E]\x00){' + str(min_length).encode() + b',}')
    unicode_strings = unicode_pattern.findall(data)
    
    # Convert strings to readable format
    readable_strings = [s.decode('ascii') for s in ascii_strings]
    readable_strings += [s.decode('utf-16le') for s in unicode_strings]
    
    return readable_strings

def analyze_strings(strings):
    """Analyze extracted strings for suspicious indicators"""
    suspicious_indicators = {
        'network': ['.com', '.net', '.org', '.ru', '.cn', 'http://', 'https://', 'ftp://', 'tcp://', 'socket', 'addr'],
        'filesystem': ['C:\\', 'cmd.exe', 'powershell', '.exe', '.dll', '.bat', '.ps1', '.vbs', 'system32', 'temp', '%temp%'],
        'registry': ['HKEY_', 'HKLM', 'HKCU', 'registry', 'RegCreateKey', 'RegSetValue'],
        'process': ['CreateProcess', 'VirtualAlloc', 'WriteProcessMemory', 'CreateRemoteThread', 'LoadLibrary', 'GetProcAddress'],
        'persistence': ['Run', 'RunOnce', 'Startup', 'Schedule', 'Task', 'WinLogon', 'Boot'],
        'evasion': ['Sleep', 'IsDebuggerPresent', 'CheckRemoteDebuggerPresent', 'GetTickCount', 'QueryPerformanceCounter'],
        'encryption': ['AES', 'RSA', 'RC4', 'XOR', 'crypt', 'encrypt', 'decrypt', 'base64', 'md5', 'sha1', 'sha256']
    }
    
    categorized_strings = {category: [] for category in suspicious_indicators}
    
    for string in strings:
        for category, indicators in suspicious_indicators.items():
            for indicator in indicators:
                if indicator.lower() in string.lower():
                    categorized_strings[category].append(string)
                    break
    
    return categorized_strings

def print_analysis(categorized_strings):
    """Print the analysis results"""
    print("[*] String Analysis Results:")
    
    for category, strings in categorized_strings.items():
        if strings:
            print(f"\n[+] {category.capitalize()} related strings:")
            for s in sorted(set(strings)):
                print(f"    - {s}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <file_path>")
        sys.exit(1)
    
    file_path = sys.argv[1]
    if not os.path.isfile(file_path):
        print(f"[!] Error: File '{file_path}' not found")
        sys.exit(1)
    
    print(f"[*] Extracting strings from {file_path}")
    strings = extract_strings(file_path)
    print(f"[*] Found {len(strings)} strings")
    
    categorized = analyze_strings(strings)
    print_analysis(categorized)
```

## 2. YARA Rules for Malware Detection

### Example 1: Basic YARA Rule Structure

```yara
rule Generic_Malware_Indicators {
    meta:
        description = "Detects common malware indicators"
        author = "Security Researcher"
        date = "2025-05-28"
        version = "1.0"
        
    strings:
        // Suspicious API calls
        $api1 = "CreateRemoteThread" ascii wide
        $api2 = "VirtualAllocEx" ascii wide
        $api3 = "WriteProcessMemory" ascii wide
        $api4 = "LoadLibraryA" ascii wide
        
        // Suspicious strings
        $str1 = "cmd.exe /c " ascii wide
        $str2 = "powershell -enc" ascii wide
        $str3 = "RegCreateKeyEx" ascii wide
        
        // Potential C2 indicators
        $c2_1 = "http://" ascii wide
        $c2_2 = ".php?id=" ascii wide
        
        // Potential evasion techniques
        $evasion1 = "IsDebuggerPresent" ascii wide
        $evasion2 = "Sleep" ascii wide
        $evasion3 = "GetTickCount" ascii wide
        
    condition:
        uint16(0) == 0x5A4D and // MZ header (PE file)
        (
            (2 of ($api*)) or
            (2 of ($str*)) or
            (any of ($c2*) and any of ($evasion*))
        )
}
```

### Example 2: Advanced YARA Rule for Ransomware Detection

```yara
rule Ransomware_Behavior_Detection {
    meta:
        description = "Detects common ransomware behaviors"
        author = "Security Researcher"
        date = "2025-05-28"
        version = "1.0"
        threat_level = "High"
        
    strings:
        // Encryption-related strings
        $encrypt1 = "AES" ascii wide nocase
        $encrypt2 = "RSA" ascii wide nocase
        $encrypt3 = "encrypt" ascii wide nocase
        $encrypt4 = "decrypt" ascii wide nocase
        $encrypt5 = "CryptEncrypt" ascii wide
        $encrypt6 = "CryptGenKey" ascii wide
        
        // Ransom note indicators
        $note1 = "your files have been encrypted" ascii wide nocase
        $note2 = "bitcoin" ascii wide nocase
        $note3 = "payment" ascii wide nocase
        $note4 = "decrypt" ascii wide nocase
        $note5 = "ransom" ascii wide nocase
        $note6 = "README" ascii wide
        
        // File operations
        $file1 = "FindFirstFile" ascii wide
        $file2 = "FindNextFile" ascii wide
        $file3 = "CreateFile" ascii wide
        $file4 = "ReadFile" ascii wide
        $file5 = "WriteFile" ascii wide
        $file6 = "DeleteFile" ascii wide
        
        // File extensions commonly targeted
        $ext1 = ".doc" ascii wide
        $ext2 = ".xls" ascii wide
        $ext3 = ".ppt" ascii wide
        $ext4 = ".pdf" ascii wide
        $ext5 = ".jpg" ascii wide
        $ext6 = ".png" ascii wide
        $ext7 = ".txt" ascii wide
        $ext8 = ".zip" ascii wide
        
        // New file extensions for encrypted files
        $new_ext1 = ".encrypted" ascii wide
        $new_ext2 = ".locked" ascii wide
        $new_ext3 = ".crypt" ascii wide
        $new_ext4 = ".crypted" ascii wide
        $new_ext5 = ".enc" ascii wide
        
    condition:
        uint16(0) == 0x5A4D and // MZ header (PE file)
        (
            // Encryption capabilities with file operations
            (2 of ($encrypt*) and 3 of ($file*)) or
            
            // Ransom note with encryption capabilities
            (2 of ($note*) and 2 of ($encrypt*)) or
            
            // File operations with new extensions
            (3 of ($file*) and 4 of ($ext*) and any of ($new_ext*)) or
            
            // Strong ransomware indicators
            (3 of ($note*) and 2 of ($new_ext*))
        )
}
```

## 3. Dynamic Analysis with Python

### Example 1: Monitoring Process Creation

```python
import os
import sys
import time
import subprocess
import psutil
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("process_monitor.log"),
        logging.StreamHandler()
    ]
)

def monitor_process(target_pid, duration=60):
    """
    Monitor a process and its children for the specified duration
    """
    start_time = time.time()
    end_time = start_time + duration
    
    # Store initial process information
    try:
        target_process = psutil.Process(target_pid)
        logging.info(f"Starting monitoring of process {target_pid} ({target_process.name()})")
        
        # Track already seen processes to avoid duplicates
        seen_processes = {target_pid}
        
        while time.time() < end_time:
            try:
                # Check if target process is still running
                if not psutil.pid_exists(target_pid):
                    logging.warning(f"Target process {target_pid} has terminated")
                    break
                
                # Get all processes
                all_processes = psutil.process_iter(['pid', 'name', 'cmdline', 'create_time'])
                
                # Check for new processes
                for proc in all_processes:
                    try:
                        pid = proc.info['pid']
                        
                        # Skip if we've already seen this process
                        if pid in seen_processes:
                            continue
                        
                        # Get process creation time
                        create_time = proc.info['create_time']
                        
                        # Only consider processes created after we started monitoring
                        if create_time >= start_time:
                            seen_processes.add(pid)
                            
                            # Get process details
                            name = proc.info['name']
                            cmdline = " ".join(proc.info['cmdline']) if proc.info['cmdline'] else ""
                            
                            # Log the new process
                            logging.info(f"New process detected: PID={pid}, Name={name}, Command={cmdline}")
                            
                            # Try to determine if this is a child of our target
                            try:
                                parent = proc.parent()
                                if parent and parent.pid in seen_processes:
                                    logging.info(f"Process {pid} is a child of PID {parent.pid}")
                            except (psutil.NoSuchProcess, psutil.AccessDenied):
                                pass
                    
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        continue
                
                # Sleep to reduce CPU usage
                time.sleep(0.5)
                
            except Exception as e:
                logging.error(f"Error during monitoring: {e}")
                
        logging.info(f"Monitoring completed. Observed {len(seen_processes)} processes.")
        
    except psutil.NoSuchProcess:
        logging.error(f"Process with PID {target_pid} not found")
    except Exception as e:
        logging.error(f"Error: {e}")

def run_and_monitor(executable_path, duration=60):
    """
    Run an executable and monitor its process activity
    """
    try:
        logging.info(f"Launching {executable_path}")
        process = subprocess.Popen(executable_path)
        pid = process.pid
        logging.info(f"Process started with PID: {pid}")
        
        # Monitor the process
        monitor_process(pid, duration)
        
        # Check if process is still running and terminate if needed
        if process.poll() is None:
            logging.info(f"Terminating process {pid}")
            process.terminate()
            process.wait(timeout=5)
            
    except Exception as e:
        logging.error(f"Error running and monitoring {executable_path}: {e}")

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(f"Usage: {sys.argv[0]} <executable_path> [duration_in_seconds]")
        sys.exit(1)
    
    executable_path = sys.argv[1]
    duration = int(sys.argv[2]) if len(sys.argv) > 2 else 60
    
    if not os.path.isfile(executable_path):
        print(f"Error: File '{executable_path}' not found")
        sys.exit(1)
    
    run_and_monitor(executable_path, duration)
```

### Example 2: Network Traffic Monitoring

```python
import sys
import time
import logging
from scapy.all import sniff, IP, TCP, UDP, DNS

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("network_monitor.log"),
        logging.StreamHandler()
    ]
)

# Track connections to detect potential C2
connections = {}
dns_queries = {}

def analyze_packet(packet):
    """Analyze a network packet for suspicious indicators"""
    try:
        # Skip packets without IP layer
        if not packet.haslayer(IP):
            return
        
        src_ip = packet[IP].src
        dst_ip = packet[IP].dst
        
        # Handle TCP traffic
        if packet.haslayer(TCP):
            src_port = packet[TCP].sport
            dst_port = packet[TCP].dport
            
            # Create connection identifier
            conn_id = f"{src_ip}:{src_port}-{dst_ip}:{dst_port}"
            
            # Track new connections
            if conn_id not in connections:
                connections[conn_id] = {
                    'first_seen': time.time(),
                    'last_seen': time.time(),
                    'packets': 1,
                    'bytes': len(packet),
                    'flags': [packet[TCP].flags]
                }
                logging.info(f"New TCP connection: {conn_id}")
            else:
                connections[conn_id]['last_seen'] = time.time()
                connections[conn_id]['packets'] += 1
                connections[conn_id]['bytes'] += len(packet)
                connections[conn_id]['flags'].append(packet[TCP].flags)
            
            # Check for suspicious ports
            suspicious_ports = [22, 23, 25, 445, 1433, 3389, 4444, 8080]
            if dst_port in suspicious_ports:
                logging.warning(f"Connection to suspicious port: {dst_ip}:{dst_port}")
            
            # Check for beaconing behavior (regular, small packets)
            if connections[conn_id]['packets'] > 5:
                avg_time = (connections[conn_id]['last_seen'] - connections[conn_id]['first_seen']) / connections[conn_id]['packets']
                avg_size = connections[conn_id]['bytes'] / connections[conn_id]['packets']
                
                # Potential beaconing: regular small packets
                if 0.9 < avg_time < 1.1 and avg_size < 100:
                    logging.warning(f"Potential beaconing detected: {conn_id} (avg interval: {avg_time:.2f}s, avg size: {avg_size:.2f} bytes)")
        
        # Handle UDP traffic
        elif packet.haslayer(UDP):
            src_port = packet[UDP].sport
            dst_port = packet[UDP].dport
            
            # Check for DNS traffic
            if packet.haslayer(DNS) and packet[DNS].qr == 0:  # DNS query
                if packet[DNS].qd:
                    query = packet[DNS].qd.qname.decode('utf-8')
                    
                    # Track DNS queries
                    if query not in dns_queries:
                        dns_queries[query] = {
                            'first_seen': time.time(),
                            'count': 1
                        }
                        logging.info(f"DNS query: {query}")
                    else:
                        dns_queries[query]['count'] += 1
                    
                    # Check for suspicious DNS patterns
                    suspicious_patterns = [
                        '.top', '.xyz', '.info', '.cc', '.tk',
                        'api.', 'cdn.', 'update.',
                        # Long random-looking domains
                        lambda q: len(q.split('.')[0]) > 20
                    ]
                    
                    for pattern in suspicious_patterns:
                        if callable(pattern):
                            if pattern(query):
                                logging.warning(f"Suspicious DNS query pattern: {query}")
                                break
                        elif pattern in query:
                            logging.warning(f"Suspicious DNS query pattern: {query} (contains {pattern})")
                            break
    
    except Exception as e:
        logging.error(f"Error analyzing packet: {e}")

def start_monitoring(interface=None, duration=60):
    """Start monitoring network traffic"""
    try:
        logging.info(f"Starting network monitoring on {'all interfaces' if not interface else interface}")
        logging.info(f"Monitoring for {duration} seconds...")
        
        # Start packet capture
        sniff(
            iface=interface,
            prn=analyze_packet,
            store=0,
            timeout=duration
        )
        
        # Summarize findings
        logging.info(f"Monitoring completed. Observed {len(connections)} connections and {len(dns_queries)} unique DNS queries.")
        
        # Report top connections
        if connections:
            logging.info("Top connections by packet count:")
            sorted_conns = sorted(connections.items(), key=lambda x: x[1]['packets'], reverse=True)
            for i, (conn_id, data) in enumerate(sorted_conns[:10]):
                logging.info(f"{i+1}. {conn_id}: {data['packets']} packets, {data['bytes']} bytes")
        
        # Report top DNS queries
        if dns_queries:
            logging.info("Top DNS queries:")
            sorted_queries = sorted(dns_queries.items(), key=lambda x: x[1]['count'], reverse=True)
            for i, (query, data) in enumerate(sorted_queries[:10]):
                logging.info(f"{i+1}. {query}: {data['count']} queries")
    
    except KeyboardInterrupt:
        logging.info("Monitoring stopped by user")
    except Exception as e:
        logging.error(f"Error during monitoring: {e}")

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] in ['-h', '--help']:
        print(f"Usage: {sys.argv[0]} [interface] [duration_in_seconds]")
        sys.exit(0)
    
    interface = sys.argv[1] if len(sys.argv) > 1 else None
    duration = int(sys.argv[2]) if len(sys.argv) > 2 else 60
    
    start_monitoring(interface, duration)
```

## 4. Memory Forensics with Volatility

### Example: Automating Memory Analysis with Python and Volatility

```python
import os
import sys
import subprocess
import json
import logging
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("memory_analysis.log"),
        logging.StreamHandler()
    ]
)

class MemoryAnalyzer:
    def __init__(self, memory_dump, output_dir=None):
        self.memory_dump = memory_dump
        self.output_dir = output_dir or f"memory_analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        # Create output directory if it doesn't exist
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)
        
        logging.info(f"Memory analysis initialized for {memory_dump}")
        logging.info(f"Results will be saved to {self.output_dir}")
    
    def run_volatility_command(self, plugin, output_file=None, additional_args=None):
        """Run a Volatility 3 plugin and return the results"""
        cmd = ["vol3", "-f", self.memory_dump, plugin]
        
        if additional_args:
            cmd.extend(additional_args)
        
        logging.info(f"Running: {' '.join(cmd)}")
        
        try:
            if output_file:
                output_path = os.path.join(self.output_dir, output_file)
                with open(output_path, 'w') as f:
                    subprocess.run(cmd, stdout=f, stderr=subprocess.PIPE, text=True, check=True)
                return output_path
            else:
                result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=True)
                return result.stdout
        except subprocess.CalledProcessError as e:
            logging.error(f"Error running Volatility command: {e}")
            logging.error(f"Error output: {e.stderr}")
            return None
    
    def identify_os(self):
        """Identify the operating system of the memory dump"""
        logging.info("Identifying operating system...")
        result = self.run_volatility_command("windows.info")
        
        if not result:
            logging.error("Failed to identify operating system")
            return None
        
        # Save the result
        with open(os.path.join(self.output_dir, "os_info.txt"), 'w') as f:
            f.write(result)
        
        return result
    
    def analyze_processes(self):
        """Analyze running processes"""
        logging.info("Analyzing processes...")
        return self.run_volatility_command("windows.pslist", "processes_pslist.txt")
    
    def analyze_process_tree(self):
        """Generate process tree"""
        logging.info("Generating process tree...")
        return self.run_volatility_command("windows.pstree", "processes_pstree.txt")
    
    def analyze_network_connections(self):
        """Analyze network connections"""
        logging.info("Analyzing network connections...")
        return self.run_volatility_command("windows.netscan", "network_connections.txt")
    
    def analyze_loaded_modules(self):
        """Analyze loaded modules/DLLs"""
        logging.info("Analyzing loaded modules...")
        return self.run_volatility_command("windows.modules", "loaded_modules.txt")
    
    def analyze_registry_hives(self):
        """Analyze registry hives"""
        logging.info("Analyzing registry hives...")
        return self.run_volatility_command("windows.registry.hivelist", "registry_hives.txt")
    
    def extract_command_history(self):
        """Extract command history"""
        logging.info("Extracting command history...")
        return self.run_volatility_command("windows.cmdline", "command_history.txt")
    
    def scan_for_malware_artifacts(self):
        """Scan for common malware artifacts"""
        logging.info("Scanning for malware artifacts...")
        
        # Check for suspicious processes
        logging.info("Checking for suspicious processes...")
        self.run_volatility_command("windows.malfind", "malfind_results.txt")
        
        # Check for process hollowing and injection
        logging.info("Checking for process hollowing...")
        self.run_volatility_command("windows.hollowfind", "hollowfind_results.txt")
        
        # Check for suspicious drivers
        logging.info("Checking for suspicious drivers...")
        self.run_volatility_command("windows.driverirp", "driver_irp_results.txt")
        
        # Check for suspicious handles
        logging.info("Checking for suspicious handles...")
        self.run_volatility_command("windows.handles", "handles_results.txt")
        
        # Check for suspicious registry entries
        logging.info("Checking for suspicious registry entries...")
        self.run_volatility_command("windows.registry.userassist", "registry_userassist.txt")
        
        # Check for suspicious services
        logging.info("Checking for suspicious services...")
        self.run_volatility_command("windows.svcscan", "services_results.txt")
    
    def extract_strings(self):
        """Extract strings from memory dump"""
        logging.info("Extracting strings from memory dump...")
        
        strings_output = os.path.join(self.output_dir, "strings_output.txt")
        
        try:
            with open(strings_output, 'w') as f:
                subprocess.run(["strings", "-a", "-td", self.memory_dump], stdout=f, stderr=subprocess.PIPE, text=True, check=True)
            logging.info(f"Strings extracted to {strings_output}")
            return strings_output
        except subprocess.CalledProcessError as e:
            logging.error(f"Error extracting strings: {e}")
            return None
    
    def generate_report(self):
        """Generate a summary report of findings"""
        logging.info("Generating summary report...")
        
        report_path = os.path.join(self.output_dir, "analysis_report.txt")
        
        with open(report_path, 'w') as report:
            report.write("=" * 80 + "\n")
            report.write("MEMORY ANALYSIS REPORT\n")
            report.write("=" * 80 + "\n\n")
            
            report.write(f"Memory Dump: {self.memory_dump}\n")
            report.write(f"Analysis Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            
            # Summarize processes
            try:
                with open(os.path.join(self.output_dir, "processes_pslist.txt"), 'r') as f:
                    processes = f.readlines()
                
                process_count = len(processes) - 2 if len(processes) > 2 else 0
                report.write(f"Processes: {process_count} running processes found\n")
                
                # List potentially suspicious processes
                suspicious_processes = []
                suspicious_names = ["cmd.exe", "powershell.exe", "rundll32.exe", "regsvr32.exe", "svchost.exe"]
                
                for line in processes[2:]:  # Skip header lines
                    for name in suspicious_names:
                        if name in line:
                            suspicious_processes.append(line.strip())
                            break
                
                if suspicious_processes:
                    report.write("\nPotentially Suspicious Processes:\n")
                    for proc in suspicious_processes[:10]:  # Limit to 10 for brevity
                        report.write(f"- {proc}\n")
                    
                    if len(suspicious_processes) > 10:
                        report.write(f"... and {len(suspicious_processes) - 10} more\n")
            except Exception as e:
                report.write(f"Error summarizing processes: {e}\n")
            
            # Summarize network connections
            try:
                with open(os.path.join(self.output_dir, "network_connections.txt"), 'r') as f:
                    connections = f.readlines()
                
                conn_count = len(connections) - 2 if len(connections) > 2 else 0
                report.write(f"\nNetwork Connections: {conn_count} connections found\n")
                
                if conn_count > 0:
                    report.write("\nExternal Connections:\n")
                    for line in connections[2:]:  # Skip header lines
                        if "127.0.0.1" not in line and "0.0.0.0" not in line:
                            report.write(f"- {line.strip()}\n")
            except Exception as e:
                report.write(f"Error summarizing network connections: {e}\n")
            
            # Summarize malware findings
            try:
                with open(os.path.join(self.output_dir, "malfind_results.txt"), 'r') as f:
                    malfind = f.readlines()
                
                if len(malfind) > 2:
                    report.write("\nPotential Malware Indicators:\n")
                    report.write(f"- {len(malfind) - 2} suspicious memory regions identified\n")
            except Exception as e:
                report.write(f"Error summarizing malware findings: {e}\n")
            
            report.write("\n" + "=" * 80 + "\n")
            report.write("ANALYSIS COMPLETE\n")
            report.write("=" * 80 + "\n")
        
        logging.info(f"Report generated: {report_path}")
        return report_path
    
    def run_full_analysis(self):
        """Run a full memory analysis"""
        logging.info("Starting full memory analysis...")
        
        self.identify_os()
        self.analyze_processes()
        self.analyze_process_tree()
        self.analyze_network_connections()
        self.analyze_loaded_modules()
        self.analyze_registry_hives()
        self.extract_command_history()
        self.scan_for_malware_artifacts()
        self.extract_strings()
        report_path = self.generate_report()
        
        logging.info("Full memory analysis completed")
        logging.info(f"Results saved to {self.output_dir}")
        
        return report_path

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(f"Usage: {sys.argv[0]} <memory_dump_file> [output_directory]")
        sys.exit(1)
    
    memory_dump = sys.argv[1]
    output_dir = sys.argv[2] if len(sys.argv) > 2 else None
    
    if not os.path.isfile(memory_dump):
        print(f"Error: Memory dump file '{memory_dump}' not found")
        sys.exit(1)
    
    analyzer = MemoryAnalyzer(memory_dump, output_dir)
    analyzer.run_full_analysis()
```

## 5. Automated Malware Sandbox Analysis

### Example: Simple Cuckoo Sandbox API Client

```python
import os
import sys
import time
import json
import requests
import logging
import argparse
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("cuckoo_analysis.log"),
        logging.StreamHandler()
    ]
)

class CuckooClient:
    def __init__(self, api_url="http://localhost:8090"):
        self.api_url = api_url
        logging.info(f"Initialized Cuckoo API client for {api_url}")
    
    def test_connection(self):
        """Test connection to Cuckoo API"""
        try:
            response = requests.get(f"{self.api_url}/cuckoo/status")
            if response.status_code == 200:
                logging.info("Successfully connected to Cuckoo API")
                return True
            else:
                logging.error(f"Failed to connect to Cuckoo API: {response.status_code}")
                return False
        except Exception as e:
            logging.error(f"Error connecting to Cuckoo API: {e}")
            return False
    
    def submit_file(self, file_path, options=None):
        """Submit a file for analysis"""
        if not os.path.isfile(file_path):
            logging.error(f"File not found: {file_path}")
            return None
        
        try:
            with open(file_path, "rb") as sample:
                files = {"file": (os.path.basename(file_path), sample)}
                
                # Default options
                data = {
                    "timeout": "120",
                    "enforce_timeout": "false",
                    "priority": "1"
                }
                
                # Update with custom options if provided
                if options:
                    data.update(options)
                
                logging.info(f"Submitting {file_path} for analysis")
                response = requests.post(
                    f"{self.api_url}/tasks/create/file",
                    files=files,
                    data=data
                )
                
                if response.status_code == 200:
                    result = response.json()
                    if "task_id" in result:
                        task_id = result["task_id"]
                        logging.info(f"File submitted successfully. Task ID: {task_id}")
                        return task_id
                    else:
                        logging.error(f"Failed to get task ID: {result}")
                        return None
                else:
                    logging.error(f"Failed to submit file: {response.status_code} - {response.text}")
                    return None
        except Exception as e:
            logging.error(f"Error submitting file: {e}")
            return None
    
    def check_task_status(self, task_id):
        """Check the status of a task"""
        try:
            response = requests.get(f"{self.api_url}/tasks/view/{task_id}")
            if response.status_code == 200:
                result = response.json()
                status = result.get("task", {}).get("status", "unknown")
                logging.info(f"Task {task_id} status: {status}")
                return status
            else:
                logging.error(f"Failed to check task status: {response.status_code} - {response.text}")
                return None
        except Exception as e:
            logging.error(f"Error checking task status: {e}")
            return None
    
    def get_task_report(self, task_id):
        """Get the report for a completed task"""
        try:
            response = requests.get(f"{self.api_url}/tasks/report/{task_id}")
            if response.status_code == 200:
                logging.info(f"Retrieved report for task {task_id}")
                return response.json()
            else:
                logging.error(f"Failed to get task report: {response.status_code} - {response.text}")
                return None
        except Exception as e:
            logging.error(f"Error getting task report: {e}")
            return None
    
    def wait_for_completion(self, task_id, check_interval=10, max_checks=60):
        """Wait for a task to complete"""
        logging.info(f"Waiting for task {task_id} to complete...")
        
        for i in range(max_checks):
            status = self.check_task_status(task_id)
            
            if status == "reported":
                logging.info(f"Task {task_id} completed successfully")
                return True
            elif status in ["failed", "error"]:
                logging.error(f"Task {task_id} failed")
                return False
            
            logging.info(f"Task {task_id} still running (check {i+1}/{max_checks}). Waiting {check_interval} seconds...")
            time.sleep(check_interval)
        
        logging.warning(f"Timeout waiting for task {task_id} to complete")
        return False
    
    def analyze_report(self, report, output_dir=None):
        """Analyze the report and extract key findings"""
        if not report:
            logging.error("No report to analyze")
            return None
        
        # Create output directory if specified
        if output_dir:
            if not os.path.exists(output_dir):
                os.makedirs(output_dir)
        
        # Extract basic information
        info = report.get("info", {})
        target = report.get("target", {})
        
        analysis_summary = {
            "task_id": info.get("id"),
            "duration": info.get("duration"),
            "file_name": target.get("file", {}).get("name"),
            "file_size": target.get("file", {}).get("size"),
            "file_type": target.get("file", {}).get("type"),
            "md5": target.get("file", {}).get("md5"),
            "sha1": target.get("file", {}).get("sha1"),
            "sha256": target.get("file", {}).get("sha256"),
            "analysis_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "signatures": [],
            "network": {
                "dns_requests": [],
                "http_requests": [],
                "connections": []
            },
            "processes": [],
            "dropped_files": []
        }
        
        # Extract signatures (detected behaviors)
        signatures = report.get("signatures", [])
        for sig in signatures:
            analysis_summary["signatures"].append({
                "name": sig.get("name"),
                "description": sig.get("description"),
                "severity": sig.get("severity")
            })
        
        # Extract network activity
        network = report.get("network", {})
        
        # DNS requests
        for dns in network.get("dns", []):
            analysis_summary["network"]["dns_requests"].append({
                "request": dns.get("request"),
                "answers": dns.get("answers", [])
            })
        
        # HTTP requests
        for http in network.get("http", []):
            analysis_summary["network"]["http_requests"].append({
                "url": http.get("url"),
                "method": http.get("method"),
                "user-agent": http.get("user-agent")
            })
        
        # TCP/UDP connections
        for conn in network.get("tcp", []) + network.get("udp", []):
            analysis_summary["network"]["connections"].append({
                "src": f"{conn.get('src')}:{conn.get('sport')}",
                "dst": f"{conn.get('dst')}:{conn.get('dport')}",
                "protocol": "tcp" if conn in network.get("tcp", []) else "udp"
            })
        
        # Extract process information
        behavior = report.get("behavior", {})
        processes = behavior.get("processes", [])
        
        for process in processes:
            proc_info = {
                "pid": process.get("pid"),
                "name": process.get("process_name"),
                "path": process.get("process_path"),
                "api_calls": []
            }
            
            # Get a sample of API calls
            for call in process.get("calls", [])[:20]:  # Limit to 20 calls per process
                proc_info["api_calls"].append({
                    "function": call.get("api"),
                    "arguments": call.get("arguments"),
                    "category": call.get("category")
                })
            
            analysis_summary["processes"].append(proc_info)
        
        # Extract dropped files
        for dropped in report.get("dropped", []):
            analysis_summary["dropped_files"].append({
                "name": dropped.get("name"),
                "path": dropped.get("path"),
                "size": dropped.get("size"),
                "type": dropped.get("type"),
                "md5": dropped.get("md5")
            })
        
        # Save the summary if output directory is specified
        if output_dir:
            summary_path = os.path.join(output_dir, "analysis_summary.json")
            with open(summary_path, 'w') as f:
                json.dump(analysis_summary, f, indent=4)
            
            # Save the full report
            report_path = os.path.join(output_dir, "full_report.json")
            with open(report_path, 'w') as f:
                json.dump(report, f, indent=4)
            
            logging.info(f"Analysis summary saved to {summary_path}")
            logging.info(f"Full report saved to {report_path}")
        
        return analysis_summary
    
    def generate_text_report(self, analysis_summary, output_dir=None):
        """Generate a human-readable text report from the analysis summary"""
        if not analysis_summary:
            logging.error("No analysis summary to generate report from")
            return None
        
        report_content = []
        report_content.append("=" * 80)
        report_content.append("MALWARE ANALYSIS REPORT")
        report_content.append("=" * 80)
        report_content.append("")
        
        # Basic information
        report_content.append("SAMPLE INFORMATION")
        report_content.append("-" * 80)
        report_content.append(f"File Name: {analysis_summary.get('file_name', 'N/A')}")
        report_content.append(f"File Size: {analysis_summary.get('file_size', 'N/A')} bytes")
        report_content.append(f"File Type: {analysis_summary.get('file_type', 'N/A')}")
        report_content.append(f"MD5: {analysis_summary.get('md5', 'N/A')}")
        report_content.append(f"SHA1: {analysis_summary.get('sha1', 'N/A')}")
        report_content.append(f"SHA256: {analysis_summary.get('sha256', 'N/A')}")
        report_content.append(f"Analysis Date: {analysis_summary.get('analysis_date', 'N/A')}")
        report_content.append(f"Analysis Duration: {analysis_summary.get('duration', 'N/A')} seconds")
        report_content.append("")
        
        # Detected behaviors (signatures)
        report_content.append("DETECTED BEHAVIORS")
        report_content.append("-" * 80)
        
        signatures = analysis_summary.get("signatures", [])
        if signatures:
            # Sort by severity (high to low)
            sorted_sigs = sorted(signatures, key=lambda x: x.get("severity", 0), reverse=True)
            
            for sig in sorted_sigs:
                report_content.append(f"[Severity: {sig.get('severity', 'N/A')}] {sig.get('name', 'N/A')}")
                report_content.append(f"  {sig.get('description', 'N/A')}")
                report_content.append("")
        else:
            report_content.append("No significant behaviors detected")
            report_content.append("")
        
        # Network activity
        report_content.append("NETWORK ACTIVITY")
        report_content.append("-" * 80)
        
        # DNS requests
        dns_requests = analysis_summary.get("network", {}).get("dns_requests", [])
        if dns_requests:
            report_content.append("DNS Requests:")
            for dns in dns_requests:
                report_content.append(f"  {dns.get('request', 'N/A')}")
                answers = dns.get("answers", [])
                if answers:
                    report_content.append(f"    Answers: {', '.join(answers)}")
            report_content.append("")
        
        # HTTP requests
        http_requests = analysis_summary.get("network", {}).get("http_requests", [])
        if http_requests:
            report_content.append("HTTP Requests:")
            for http in http_requests:
                report_content.append(f"  {http.get('method', 'GET')} {http.get('url', 'N/A')}")
                report_content.append(f"    User-Agent: {http.get('user-agent', 'N/A')}")
            report_content.append("")
        
        # TCP/UDP connections
        connections = analysis_summary.get("network", {}).get("connections", [])
        if connections:
            report_content.append("Network Connections:")
            for conn in connections:
                report_content.append(f"  {conn.get('protocol', 'N/A').upper()}: {conn.get('src', 'N/A')} -> {conn.get('dst', 'N/A')}")
            report_content.append("")
        
        if not dns_requests and not http_requests and not connections:
            report_content.append("No network activity detected")
            report_content.append("")
        
        # Process activity
        processes = analysis_summary.get("processes", [])
        if processes:
            report_content.append("PROCESS ACTIVITY")
            report_content.append("-" * 80)
            
            for process in processes:
                report_content.append(f"Process: {process.get('name', 'N/A')} (PID: {process.get('pid', 'N/A')})")
                report_content.append(f"Path: {process.get('path', 'N/A')}")
                
                api_calls = process.get("api_calls", [])
                if api_calls:
                    report_content.append("  Notable API Calls:")
                    
                    # Group API calls by category
                    categories = {}
                    for call in api_calls:
                        category = call.get("category", "unknown")
                        if category not in categories:
                            categories[category] = []
                        categories[category].append(call)
                    
                    for category, calls in categories.items():
                        report_content.append(f"    {category.upper()}:")
                        for call in calls[:5]:  # Limit to 5 calls per category
                            args_str = ", ".join([f"{k}={v}" for k, v in call.get("arguments", {}).items()])
                            report_content.append(f"      {call.get('function', 'N/A')}({args_str})")
                        
                        if len(calls) > 5:
                            report_content.append(f"      ... and {len(calls) - 5} more {category} calls")
                
                report_content.append("")
        
        # Dropped files
        dropped_files = analysis_summary.get("dropped_files", [])
        if dropped_files:
            report_content.append("DROPPED FILES")
            report_content.append("-" * 80)
            
            for file in dropped_files:
                report_content.append(f"Name: {file.get('name', 'N/A')}")
                report_content.append(f"Path: {file.get('path', 'N/A')}")
                report_content.append(f"Type: {file.get('type', 'N/A')}")
                report_content.append(f"Size: {file.get('size', 'N/A')} bytes")
                report_content.append(f"MD5: {file.get('md5', 'N/A')}")
                report_content.append("")
        
        # Conclusion
        report_content.append("CONCLUSION")
        report_content.append("-" * 80)
        
        # Determine maliciousness based on signatures
        high_severity_count = sum(1 for sig in signatures if sig.get("severity", 0) >= 3)
        medium_severity_count = sum(1 for sig in signatures if sig.get("severity", 0) == 2)
        
        if high_severity_count > 0:
            report_content.append("VERDICT: MALICIOUS")
            report_content.append(f"The sample exhibits {high_severity_count} high-severity malicious behaviors.")
        elif medium_severity_count > 0:
            report_content.append("VERDICT: SUSPICIOUS")
            report_content.append(f"The sample exhibits {medium_severity_count} suspicious behaviors that warrant further investigation.")
        else:
            report_content.append("VERDICT: POTENTIALLY BENIGN")
            report_content.append("No significant malicious behaviors were detected, but this does not guarantee the sample is safe.")
        
        report_content.append("")
        report_content.append("=" * 80)
        
        # Join all lines
        report_text = "\n".join(report_content)
        
        # Save the report if output directory is specified
        if output_dir:
            report_path = os.path.join(output_dir, "analysis_report.txt")
            with open(report_path, 'w') as f:
                f.write(report_text)
            logging.info(f"Text report saved to {report_path}")
        
        return report_text

def main():
    parser = argparse.ArgumentParser(description="Cuckoo Sandbox API Client")
    parser.add_argument("file", help="File to analyze")
    parser.add_argument("--api-url", default="http://localhost:8090", help="Cuckoo API URL")
    parser.add_argument("--output-dir", help="Directory to save results")
    parser.add_argument("--timeout", type=int, default=120, help="Analysis timeout in seconds")
    parser.add_argument("--enforce-timeout", action="store_true", help="Enforce the timeout value")
    
    args = parser.parse_args()
    
    # Create output directory if specified
    if args.output_dir and not os.path.exists(args.output_dir):
        os.makedirs(args.output_dir)
    
    # Initialize client
    client = CuckooClient(api_url=args.api_url)
    
    # Test connection
    if not client.test_connection():
        sys.exit(1)
    
    # Submit file
    options = {
        "timeout": str(args.timeout),
        "enforce_timeout": "true" if args.enforce_timeout else "false"
    }
    
    task_id = client.submit_file(args.file, options)
    if not task_id:
        sys.exit(1)
    
    # Wait for completion
    if not client.wait_for_completion(task_id):
        sys.exit(1)
    
    # Get report
    report = client.get_task_report(task_id)
    if not report:
        sys.exit(1)
    
    # Analyze report
    analysis_summary = client.analyze_report(report, args.output_dir)
    if not analysis_summary:
        sys.exit(1)
    
    # Generate text report
    text_report = client.generate_text_report(analysis_summary, args.output_dir)
    if text_report:
        print("\n" + text_report)
    
    logging.info("Analysis completed successfully")

if __name__ == "__main__":
    main()
```

These code snippets provide practical examples of key malware analysis techniques, from basic static analysis to dynamic monitoring and automated sandbox analysis. They can be used as starting points for research projects or as educational tools for understanding the practical aspects of malware analysis.
